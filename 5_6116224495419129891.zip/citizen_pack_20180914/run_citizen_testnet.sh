#!/bin/sh

echo "Run citizen with port 7100..."
loop citizen -r https://testwallet.icon.foundation -o ./conf/citizen_testnet.json &

echo "Run iconservice for citizen 7100 start!"
iconservice start -c ./conf/iconservice_testnet.json &

echo "Run iconrpcserver for citizen 7100 start!"
iconrpcserver start -p 9000 -c conf/iconrpcserver_testnet.json &
