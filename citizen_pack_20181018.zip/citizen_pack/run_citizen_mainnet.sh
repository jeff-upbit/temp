#!/bin/sh
export REDIRECT_PROTOCOL=https

echo "Run citizen with port 7100..."
loop citizen -r https://wallet.icon.foundation -o ./conf/citizen_mainnet.json &

echo "Run iconservice for citizen 7100 start!"
iconservice start -c ./conf/iconservice_mainnet.json &

echo "Run iconrpcserver for citizen 7100 start!"
iconrpcserver start -p 9000 -c conf/iconrpcserver_mainnet.json &
