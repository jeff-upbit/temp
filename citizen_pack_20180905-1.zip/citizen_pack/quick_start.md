## QuickStart Guide for loopchain-iconservice as CitizenNode

## Make Virtual Env for Python 3.6.5 (recommended version, 3.7 is not supported, possible versions are 3.6.x)
 * check your python version
 ```
 $ python3 -V
 ``` 
 * make virtual env and apply
 ```
 $ virtualenv -p python3 ./venv
 $ source ./venv/bin/activate
 ```
 * check virtual env python version
 ```
 $ python -V
 ```

## necessary tools for package install
automake, pkg-config, libtool, leveldb, rabbitmq, openssl

( see: docs/3. setup/rabbitmq_setting.md )

## Install loopchain packages
```
$ pip3 install ./whl/iconcommons-1.0.5-py3-none-any.whl
$ pip3 install ./whl/iconrpcserver-1.0.5-py3-none-any.whl
$ pip3 install ./whl/iconservice-1.0.5-py3-none-any.whl
$ pip3 install ./whl/loopchain-1.21.10-py3-none-any.whl
```

## Make key file with pass phrase.
```
$ cd keys
$ openssl ecparam -genkey -name secp256k1 | openssl ec -aes-256-cbc -out my_private.pem    # generate private key
$ openssl ec -in my_private.pem  -pubout -out my_public.pem                                # generate public key
$ cd ..
```

## Change configuration. (ex. password for key file)
> In the ```./conf/citizen_{testnet or mainnet}.json``` configuration file, enter the following configuration values.
> The TWO settings marked as number below are required to be entered manually.

```
{
  "LOOPCHAIN_DEFAULT_CHANNEL": "icon_dex",
  "CHANNEL_OPTION" : {
    "icon_dex": {
      ...,
      ...,
      "public_path": "/resources/default_pki/my_public.pem",  
      "private_path": "/resources/default_pki/my_private.pem",
      "private_password": "PASSWORD_OF_YOUR_KEY"   <==== 1. NEED TO CHANGE
    }
  },
  ...,
  ...,
  "LOOPCHAIN_HOST": "PUBLIC_IP_OF_CITIZEN_NODE"   <====  2.  NEED TO CHANGE
}
```

## Run Citizen Node to TESTNET(of ICON.foundation)
```
$ ./run_citizen_testnet.sh
```

## Run Citizen Node to MAINNET(of ICON.foundation)
```
$ ./run_citizen_mainnet.sh
```

## Stop all
```This script does not support all platforms and may need to be modified. (Please refer to the script.)
$ ./stop_all.sh
```

## Clean up (delete log, delete db)
```
$ rm -rf log
$ rm -rf .storage*
```