## QuickStart Guide for loopchain-iconservice as CitizenNode

## Python Installation
 * Install **pyenv**
 ```
 $ sudo yum update
 $ sudo yum install git zlib-devel bzip2 bzip2-devel readline-devel sqlite sqlite-devel openssl-devel \
   xz xz-devel libffi-devel gcc gcc-c++ automake libtool -y
 $ curl -L https://github.com/pyenv/pyenv-installer/raw/master/bin/pyenv-installer | bash
 ``` 
 
 * Append the following commands to ~/.bash_profile
 ```
 export PATH="/home/centos/.pyenv/bin:$PATH"
 eval "$(pyenv init -)"
 eval "$(pyenv virtualenv-init -)"
 ```
 * Apply for the profile
 ```
 source ~/.bash_profile 
 ```
 * Install **python 3.6.5**
 ```
 pyenv install 3.6.5
 pyenv shell 3.6.5
 ```

## Make Virtual Environment for Python 3.6.5 (3.7 is not supported yet)
 * Change working directory to citizen pack directory.
 ```
 $ cd CitizenPack
 ```
 
 * Install virtualenv
 ```
 $ pip3 install virtualenv
 ```
 
 * make virtual environment and apply
 ```
 $ virtualenv -p python3.6 venv
 $ source venv/bin/activate
 ```
 
## RabbitMQ Installation
 * Install erlang
 ```
 $ sudo yum install wget epel-release -y
 $ wget https://packages.erlang-solutions.com/erlang-solutions-1.0-1.noarch.rpm
 $ sudo rpm -Uvh erlang-solutions-1.0-1.noarch.rpm
 $ sudo yum install erlang -y
 ```
 
 * Install RabbitMQ
 ```
 $ sudo rpm --import https://www.rabbitmq.com/rabbitmq-release-signing-key.asc
 $ wget https://dl.bintray.com/rabbitmq/all/rabbitmq-server/3.7.7/rabbitmq-server-3.7.7-1.el7.noarch.rpm
 $ sudo yum install rabbitmq-server-3.7.7-1.el7.noarch.rpm -y
 ```
 
 * Run RabbitMQ 
 ```
 $ sudo systemctl enable rabbitmq-server
 $ sudo systemctl start rabbitmq-server
 ```
 
## Install loopchain packages
```
$ pip3 install ./whl/iconcommons-1.0.5-py3-none-any.whl
$ pip3 install ./whl/iconrpcserver-1.0.5-py3-none-any.whl
$ pip3 install ./whl/iconservice-1.0.5-py3-none-any.whl
$ pip3 install ./whl/loopchain-1.21.10-py3-none-any.whl
```

## Make key file with pass phrase 'password' for default configure
```
$ cd keys
$ openssl ecparam -genkey -name secp256k1 | openssl ec -aes-256-cbc -out my_private.pem    # generate private key
$ openssl ec -in my_private.pem  -pubout -out my_public.pem                                # generate public key
$ cd ..
```

## Change configuration. (ex. password for key file)
> In the ```./conf/citizen_{testnet or mainnet}.json``` configuration file, enter the following configuration values.
> The TWO settings marked as number below are required to be entered manually.

```
{
  "LOOPCHAIN_DEFAULT_CHANNEL": "icon_dex",
  "CHANNEL_OPTION" : {
    "icon_dex": {
      ...,
      ...,
      "public_path": "/resources/default_pki/my_public.pem",  
      "private_path": "/resources/default_pki/my_private.pem",
      "private_password": "PASSWORD_OF_YOUR_KEY"   <==== 1. NEED TO CHANGE
    }
  },
  ...,
  ...,
  "LOOPCHAIN_HOST": "PUBLIC_IP_OF_CITIZEN_NODE"   <====  2.  NEED TO CHANGE
}
```

## Run Citizen Node to TESTNET(of ICON.foundation)
```
$ ./run_citizen_testnet.sh
```

## Run Citizen Node to MAINNET(of ICON.foundation)
```
$ ./run_citizen_mainnet.sh
```

## Stop all
```This script does not support all platforms and may need to be modified. (Please refer to the script.)
$ ./stop_all.sh
```

## Clean up (delete log, delete db)
```
$ rm -rf log
$ rm -rf .storage*
```
